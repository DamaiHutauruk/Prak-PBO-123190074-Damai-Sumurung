/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

import java.util.Scanner;

/**
 *
 * @author Damai Hutauruk
 */
public class Utama1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        Anak1 anak1 = new Anak1("Bambang", 15, 170);
        Anak2 anak2 = new Anak2("Pamungkas", 20, 180);
        Anak3 anak3 = new Anak3("Putra", 17, 175);
        
        anak1.bekerja();
        anak2.bekerja();
        anak3.bekerja();
    }
}
