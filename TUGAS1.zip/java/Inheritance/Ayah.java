/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author Damai Hutauruk
 */
public class Ayah {
    String nama;
    int umur;
    int tinggi;
    
    public Ayah(String nama, int umur, int tinggi) {
        this.nama = nama;
        this.umur = umur;
        this.tinggi = tinggi;
    }
    
    void berumur(){
        System.out.println("berumur" + umur);
    }
    
    void bekerja(){
        System.out.println(nama + " suka bekerja");
    }
}
