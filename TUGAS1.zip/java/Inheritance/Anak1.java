/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author Damai Hutauruk
 */
public class Anak1 extends Ayah{
    public Anak1(String nama, int umur, int tinggi){
           super(nama, umur, tinggi);
    }
}
