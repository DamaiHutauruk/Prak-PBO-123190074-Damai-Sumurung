/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorphism;

/**
 *
 * @author Damai Hutauruk
 */
public class Main {
    public static void main(String[] args) {
        
        BangunDatar LingkaranDua = new Lingkaran(8);
        BangunDatar PersegiDua = new Persegi(2,4);
        
        System.out.println("Luas Lingkaran = " + LingkaranDua.luas());
        System.out.println("Luas Persegi = " + PersegiDua.luas(3,4));
    }
}
