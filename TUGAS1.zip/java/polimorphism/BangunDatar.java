/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorphism;

/**
 *
 * @author Damai Hutauruk
 */
public class BangunDatar {
   double luas(){
       System.out.println("ini luas");
       return 0;
   } 
   
   double luas(int a, int b){
       System.out.println("ini luas");
       return 0;
   } 
   
   double keliling(){
       System.out.println("ini keliling");
       return 0;
   } 
}
