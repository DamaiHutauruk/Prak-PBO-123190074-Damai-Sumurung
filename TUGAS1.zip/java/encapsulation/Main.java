/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulation;

import java.util.Scanner;

/**
 *
 * @author Damai Hutauruk
 */
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        User dodi = new User("dodi123", "12345");
        
        String username, password;
        
        System.out.print("Masukan Username : ");
        username = input.next();
        System.out.print("Masukan Password : ");
        password = input.next();
        
        if (dodi.login(username, password)) {
            System.out.println("Berhasil LOGIN");
        }else{
            System.out.println("Gagal LOGIN");
        }
    }
}
