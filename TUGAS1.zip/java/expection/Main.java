/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expection;

import java.util.Scanner;

/**
 *
 * @author Damai Hutauruk
 */
public class Main {
     public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
         
         int nilai = 0;
         int hasil = 0;
         
         try{
             System.out.print("Masukan nilai : ");
             nilai = input.nextInt();
             
             String[] nama = new String[10];
             nama[1] = "Budi";
             
             hasil = 5/0;
         } catch (ArithmeticException error){
             System.out.println("Erornya adalah " + error.getMessage());
             hasil = 1;
         }
         catch (Exception error){
             System.out.println("Erornya adalah " + error.getMessage());
         }
         finally {
             System.out.println("Nilaimu adalah " + nilai);
         }

         System.out.println("hasil = " + hasil);
     
    }
}     